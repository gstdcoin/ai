--
-- PostgreSQL database dump
--

\restrict pVpwGXJ0S2XgdAPgts1XOPSe7Ldzo1iN8pXS0j4Tc2YsWHQ7RDcW8fzCF3ufhVg

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: devices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.devices (
    id integer NOT NULL,
    device_id character varying(255) NOT NULL,
    wallet_address character varying(100),
    trust_score double precision DEFAULT 50.0,
    last_active timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    last_seen_at timestamp with time zone DEFAULT now(),
    is_active boolean DEFAULT true,
    last_ip character varying(45),
    device_type character varying(50),
    version character varying(20)
);


--
-- Name: TABLE devices; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.devices IS 'Registered computing devices (workers)';


--
-- Name: COLUMN devices.device_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.devices.device_id IS 'Unique device fingerprint/identifier';


--
-- Name: COLUMN devices.wallet_address; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.devices.wallet_address IS 'Wallet address associated with device (multiple devices per wallet allowed)';


--
-- Name: COLUMN devices.trust_score; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.devices.trust_score IS 'Device trust score for enterprise features (0.0 to 1.0)';


--
-- Name: COLUMN devices.last_seen_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.devices.last_seen_at IS 'Last time device was seen/active';


--
-- Name: COLUMN devices.is_active; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.devices.is_active IS 'Whether device is currently active';


--
-- Name: devices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.devices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: devices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.devices_id_seq OWNED BY public.devices.id;


--
-- Name: error_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.error_logs (
    id integer NOT NULL,
    error_type character varying(50) NOT NULL,
    error_message text NOT NULL,
    stack_trace text,
    severity character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: error_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.error_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: error_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.error_logs_id_seq OWNED BY public.error_logs.id;


--
-- Name: failed_payouts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.failed_payouts (
    id integer NOT NULL,
    task_id text,
    error_message text,
    retry_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    payout_type text DEFAULT 'worker'::text,
    recipient_address text,
    amount numeric(20,9) DEFAULT 0,
    amount_gstd numeric(20,9) DEFAULT 0,
    max_retries integer DEFAULT 5,
    last_attempt_at timestamp with time zone,
    next_retry_at timestamp with time zone,
    status text DEFAULT 'pending'::text
);


--
-- Name: failed_payouts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.failed_payouts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: failed_payouts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.failed_payouts_id_seq OWNED BY public.failed_payouts.id;


--
-- Name: golden_reserve_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.golden_reserve_log (
    id integer NOT NULL,
    amount numeric(20,9),
    change_type text,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: golden_reserve_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.golden_reserve_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: golden_reserve_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.golden_reserve_log_id_seq OWNED BY public.golden_reserve_log.id;


--
-- Name: jetton_balances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.jetton_balances (
    address text NOT NULL,
    balance text DEFAULT '0'::text,
    symbol text DEFAULT 'GSTD'::text
);


--
-- Name: network_stats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.network_stats (
    id integer NOT NULL,
    total_tasks integer DEFAULT 0,
    active_nodes integer DEFAULT 0,
    total_rewards numeric(20,9) DEFAULT 0,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    total_nodes integer DEFAULT 0,
    total_workers_paid numeric(20,9) DEFAULT 0,
    total_gstd_paid numeric(20,9) DEFAULT 0,
    system_status text DEFAULT 'Operational'::text,
    golden_reserve_xaut numeric(20,9) DEFAULT 0,
    total_gstd_burned numeric(20,9) DEFAULT 0
);


--
-- Name: network_stats_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.network_stats_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: network_stats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.network_stats_id_seq OWNED BY public.network_stats.id;


--
-- Name: node_efficiency; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.node_efficiency (
    node_id text NOT NULL,
    efficiency_score numeric DEFAULT 100,
    tasks_completed integer DEFAULT 0
);


--
-- Name: nodes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nodes (
    id integer NOT NULL,
    owner_address text NOT NULL,
    node_name text,
    status text DEFAULT 'offline'::text,
    ip_address text,
    version text,
    cpu_model text,
    gpu_model text,
    last_ping timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    wallet_address character varying(100),
    name text DEFAULT 'Unnamed Device'::text,
    device_type text DEFAULT 'generic'::text,
    last_seen timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: nodes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.nodes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: nodes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.nodes_id_seq OWNED BY public.nodes.id;


--
-- Name: payout_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payout_transactions (
    id integer NOT NULL,
    task_id text,
    executor_address text,
    amount numeric,
    status text,
    created_at timestamp without time zone DEFAULT now(),
    tx_hash text,
    amount_ton numeric(20,9) DEFAULT 0,
    query_id text,
    amount_gstd numeric(20,9) DEFAULT 0,
    confirmed_at timestamp with time zone
);


--
-- Name: payout_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payout_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payout_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payout_transactions_id_seq OWNED BY public.payout_transactions.id;


--
-- Name: pool_stats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pool_stats (
    id integer NOT NULL,
    total_staked_ton numeric(20,9) DEFAULT 0,
    total_staked_gstd numeric(20,9) DEFAULT 0,
    active_workers integer DEFAULT 0,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: pool_stats_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pool_stats_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pool_stats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pool_stats_id_seq OWNED BY public.pool_stats.id;


--
-- Name: processed_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.processed_payments (
    id integer NOT NULL,
    tx_hash character varying(64) NOT NULL,
    task_id character varying(255),
    processed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: processed_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.processed_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: processed_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.processed_payments_id_seq OWNED BY public.processed_payments.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_migrations (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    applied_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: schema_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.schema_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: schema_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.schema_migrations_id_seq OWNED BY public.schema_migrations.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tasks (
    task_id text NOT NULL,
    requester_address text,
    task_type text,
    operation text,
    model text,
    labor_compensation_ton numeric(20,9),
    priority_score numeric(20,9) DEFAULT 0,
    status text DEFAULT 'pending'::text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    escrow_status text DEFAULT 'pending'::text,
    confidence_depth integer DEFAULT 1,
    assigned_device text,
    completed_at timestamp with time zone,
    device_id text,
    worker_address text,
    result_data text,
    error_message text,
    category text DEFAULT 'general'::text,
    sub_status text,
    worker_id text,
    input_source text,
    input_hash text,
    constraints_time_limit_sec integer DEFAULT 0,
    constraints_max_energy_mwh integer DEFAULT 0,
    validation_method text DEFAULT 'standard'::text,
    escrow_address text,
    escrow_amount_ton numeric(20,9) DEFAULT 0,
    geo_restriction text,
    is_private boolean DEFAULT false,
    executor_reward_ton numeric(20,9) DEFAULT 0,
    platform_fee_ton numeric(20,9) DEFAULT 0,
    timeout_at timestamp with time zone,
    result_submitted_at timestamp with time zone,
    result_nonce text,
    result_proof text,
    execution_time_ms integer,
    min_trust_score integer DEFAULT 0,
    redundancy_factor integer DEFAULT 1,
    is_spot_check boolean DEFAULT false,
    assigned_at timestamp with time zone,
    total_reward_pool numeric(18,9),
    executor_payout_tx_hash character varying(64),
    executor_payout_status character varying(20) DEFAULT 'pending'::character varying,
    certainty_gravity_score numeric(10,6) DEFAULT 0.0,
    reward_gstd double precision DEFAULT 0,
    reward_ton double precision DEFAULT 0
);


--
-- Name: COLUMN tasks.executor_payout_tx_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.executor_payout_tx_hash IS 'Transaction hash of the GSTD transfer to executor';


--
-- Name: COLUMN tasks.executor_payout_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.executor_payout_status IS 'Status of executor payout: pending, confirmed, failed';


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transactions (
    id integer NOT NULL,
    wallet_address text,
    tx_hash text,
    amount numeric(20,9),
    type text,
    status text DEFAULT 'completed'::text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.transactions_id_seq OWNED BY public.transactions.id;


--
-- Name: user_balances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_balances (
    address text NOT NULL,
    balance_ton numeric(20,9) DEFAULT 0,
    balance_gstd numeric(20,9) DEFAULT 0,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: user_stats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_stats (
    address text NOT NULL,
    tasks_completed integer DEFAULT 0,
    total_earned_ton numeric(20,9) DEFAULT 0,
    total_earned_gstd numeric(20,9) DEFAULT 0
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    address text NOT NULL,
    trust_score numeric(5,2) DEFAULT 50.0,
    role text DEFAULT 'user'::text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    auth_nonce text,
    is_active boolean DEFAULT true,
    last_login timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: wallet_access_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wallet_access_log (
    id integer NOT NULL,
    wallet_address character varying(66) NOT NULL,
    operation character varying(50) NOT NULL,
    success boolean NOT NULL,
    details text,
    accessed_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: wallet_access_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.wallet_access_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: wallet_access_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.wallet_access_log_id_seq OWNED BY public.wallet_access_log.id;


--
-- Name: withdrawal_locks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.withdrawal_locks (
    id integer NOT NULL,
    task_id character varying(255) NOT NULL,
    worker_wallet character varying(48) NOT NULL,
    amount_gstd numeric(18,9) NOT NULL,
    status character varying(20) DEFAULT 'pending_approval'::character varying NOT NULL,
    approved_by character varying(48),
    approved_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    notes text
);


--
-- Name: withdrawal_locks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.withdrawal_locks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: withdrawal_locks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.withdrawal_locks_id_seq OWNED BY public.withdrawal_locks.id;


--
-- Name: worker_rewards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.worker_rewards (
    id integer NOT NULL,
    worker_address text,
    task_id text,
    amount numeric(20,9),
    status text DEFAULT 'pending'::text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: worker_rewards_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.worker_rewards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: worker_rewards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.worker_rewards_id_seq OWNED BY public.worker_rewards.id;


--
-- Name: devices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices ALTER COLUMN id SET DEFAULT nextval('public.devices_id_seq'::regclass);


--
-- Name: error_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.error_logs ALTER COLUMN id SET DEFAULT nextval('public.error_logs_id_seq'::regclass);


--
-- Name: failed_payouts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_payouts ALTER COLUMN id SET DEFAULT nextval('public.failed_payouts_id_seq'::regclass);


--
-- Name: golden_reserve_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.golden_reserve_log ALTER COLUMN id SET DEFAULT nextval('public.golden_reserve_log_id_seq'::regclass);


--
-- Name: network_stats id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.network_stats ALTER COLUMN id SET DEFAULT nextval('public.network_stats_id_seq'::regclass);


--
-- Name: nodes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodes ALTER COLUMN id SET DEFAULT nextval('public.nodes_id_seq'::regclass);


--
-- Name: payout_transactions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payout_transactions ALTER COLUMN id SET DEFAULT nextval('public.payout_transactions_id_seq'::regclass);


--
-- Name: pool_stats id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pool_stats ALTER COLUMN id SET DEFAULT nextval('public.pool_stats_id_seq'::regclass);


--
-- Name: processed_payments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.processed_payments ALTER COLUMN id SET DEFAULT nextval('public.processed_payments_id_seq'::regclass);


--
-- Name: schema_migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_migrations ALTER COLUMN id SET DEFAULT nextval('public.schema_migrations_id_seq'::regclass);


--
-- Name: transactions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions ALTER COLUMN id SET DEFAULT nextval('public.transactions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: wallet_access_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallet_access_log ALTER COLUMN id SET DEFAULT nextval('public.wallet_access_log_id_seq'::regclass);


--
-- Name: withdrawal_locks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.withdrawal_locks ALTER COLUMN id SET DEFAULT nextval('public.withdrawal_locks_id_seq'::regclass);


--
-- Name: worker_rewards id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.worker_rewards ALTER COLUMN id SET DEFAULT nextval('public.worker_rewards_id_seq'::regclass);


--
-- Data for Name: devices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.devices (id, device_id, wallet_address, trust_score, last_active, created_at, last_seen_at, is_active, last_ip, device_type, version) FROM stdin;
\.


--
-- Data for Name: error_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.error_logs (id, error_type, error_message, stack_trace, severity, created_at) FROM stdin;
\.


--
-- Data for Name: failed_payouts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.failed_payouts (id, task_id, error_message, retry_count, created_at, payout_type, recipient_address, amount, amount_gstd, max_retries, last_attempt_at, next_retry_at, status) FROM stdin;
\.


--
-- Data for Name: golden_reserve_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.golden_reserve_log (id, amount, change_type, "timestamp") FROM stdin;
\.


--
-- Data for Name: jetton_balances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.jetton_balances (address, balance, symbol) FROM stdin;
\.


--
-- Data for Name: network_stats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.network_stats (id, total_tasks, active_nodes, total_rewards, updated_at, total_nodes, total_workers_paid, total_gstd_paid, system_status, golden_reserve_xaut, total_gstd_burned) FROM stdin;
1	6	1	0.300000000	2026-01-12 10:16:36.701482+00	0	0.000000000	0.000000000	Operational	0.000000000	0.000000000
\.


--
-- Data for Name: node_efficiency; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.node_efficiency (node_id, efficiency_score, tasks_completed) FROM stdin;
\.


--
-- Data for Name: nodes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nodes (id, owner_address, node_name, status, ip_address, version, cpu_model, gpu_model, last_ping, created_at, wallet_address, name, device_type, last_seen) FROM stdin;
\.


--
-- Data for Name: payout_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payout_transactions (id, task_id, executor_address, amount, status, created_at, tx_hash, amount_ton, query_id, amount_gstd, confirmed_at) FROM stdin;
\.


--
-- Data for Name: pool_stats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pool_stats (id, total_staked_ton, total_staked_gstd, active_workers, updated_at) FROM stdin;
1	0.000000000	0.000000000	0	2026-01-12 07:26:02.052237+00
\.


--
-- Data for Name: processed_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.processed_payments (id, tx_hash, task_id, processed_at) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.schema_migrations (id, name, applied_at) FROM stdin;
1	add_new_fields.sql	2026-01-12 17:15:17.077579
2	v10_failed_payouts.sql	2026-01-12 17:15:17.096132
3	v11_withdrawal_locks.sql	2026-01-12 17:15:17.127862
4	v12_processed_payments.sql	2026-01-12 17:15:17.154943
5	v13_executor_payout_tracking.sql	2026-01-12 17:15:17.164416
6	v14_fix_wallet_address_and_priority.sql	2026-01-12 17:15:17.260517
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tasks (task_id, requester_address, task_type, operation, model, labor_compensation_ton, priority_score, status, created_at, escrow_status, confidence_depth, assigned_device, completed_at, device_id, worker_address, result_data, error_message, category, sub_status, worker_id, input_source, input_hash, constraints_time_limit_sec, constraints_max_energy_mwh, validation_method, escrow_address, escrow_amount_ton, geo_restriction, is_private, executor_reward_ton, platform_fee_ton, timeout_at, result_submitted_at, result_nonce, result_proof, execution_time_ms, min_trust_score, redundancy_factor, is_spot_check, assigned_at, total_reward_pool, executor_payout_tx_hash, executor_payout_status, certainty_gravity_score, reward_gstd, reward_ton) FROM stdin;
FINAL_PERSISTENT_TASK	system	inference	\N	llama-3	0.500000000	0.000000000	pending	2026-01-12 01:11:44.096027+00	confirmed	1	\N	\N	\N	\N	\N	\N	general	\N	\N	\N	\N	0	0	standard	\N	0.000000000	\N	f	0.000000000	0.000000000	\N	\N	\N	\N	\N	0	1	f	\N	\N	\N	pending	0.000000	0	0
FINAL_TEST_TASK_001	system	inference	\N	llama-3	0.500000000	0.000000000	pending	2026-01-12 01:13:14.22703+00	confirmed	1	\N	\N	\N	\N	\N	\N	general	\N	\N	\N	\N	0	0	standard	\N	0.000000000	\N	f	0.000000000	0.000000000	\N	\N	\N	\N	\N	0	1	f	\N	\N	\N	pending	0.000000	0	0
TASK_2026-01-12 07:19:50.440278+00	system	inference	chat	llama-3	1.000000000	0.000000000	pending	2026-01-12 07:19:50.440278+00	confirmed	1	\N	\N	\N	\N	\N	\N	general	\N	\N	\N	\N	0	0	standard	\N	0.000000000	\N	f	0.000000000	0.000000000	\N	\N	\N	\N	\N	0	1	f	\N	\N	\N	pending	0.000000	0	0
WALLET_TASK_1768202474.287529	0:a45c594d46cb9b529ed487b960fd2714a8b0a27dfd5008bb1d414d1aee4a61a9	inference	chat	llama-3	2.000000000	0.000000000	pending	2026-01-12 07:21:14.287529+00	confirmed	1	\N	\N	\N	\N	\N	\N	general	\N	\N	\N	\N	0	0	standard	\N	0.000000000	\N	f	0.000000000	0.000000000	\N	\N	\N	\N	\N	0	1	f	\N	\N	\N	pending	0.000000	0	0
HISTORIC_1	system	inference	\N	llama-3	0.100000000	0.000000000	completed	2026-01-12 05:49:17.613406+00	pending	1	\N	2026-01-12 05:49:17.613406+00	\N	\N	\N	\N	general	\N	\N	\N	\N	0	0	standard	\N	0.000000000	\N	f	0.000000000	0.000000000	\N	\N	\N	\N	\N	0	1	f	\N	\N	\N	pending	0.000000	0	0
HISTORIC_2	system	inference	\N	llama-3	0.200000000	0.000000000	completed	2026-01-12 06:49:17.613406+00	pending	1	\N	2026-01-12 06:49:17.613406+00	\N	\N	\N	\N	general	\N	\N	\N	\N	0	0	standard	\N	0.000000000	\N	f	0.000000000	0.000000000	\N	\N	\N	\N	\N	0	1	f	\N	\N	\N	pending	0.000000	0	0
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transactions (id, wallet_address, tx_hash, amount, type, status, created_at) FROM stdin;
1	0:a45c594d46cb9b529ed487b960fd2714a8b0a27dfd5008bb1d414d1aee4a61a9	initial_sync	0.300000000	reward	completed	2026-01-12 10:26:32.548166+00
\.


--
-- Data for Name: user_balances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_balances (address, balance_ton, balance_gstd, updated_at) FROM stdin;
0:a45c594d46cb9b529ed487b960fd2714a8b0a27dfd5008bb1d414d1aee4a61a9	0.000000000	0.000000000	2026-01-12 10:18:17.447472+00
\.


--
-- Data for Name: user_stats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_stats (address, tasks_completed, total_earned_ton, total_earned_gstd) FROM stdin;
EQA--JXG8VSyBJmLMqb2J2t4Pya0TS9SXHh7vHh8Iez25sLp	0	0.000000000	0.000000000
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, address, trust_score, role, created_at, auth_nonce, is_active, last_login) FROM stdin;
4	a45c594d46cb9b529ed487b960fd2714a8b0a27dfd5008bb1d414d1aee4a61a9	50.00	admin	2026-01-12 11:42:50.131891+00	\N	t	2026-01-12 11:42:50.131891+00
2	0:a45c594d46cb9b529ed487b960fd2714a8b0a27dfd5008bb1d414d1aee4a61a9	50.00	admin	2026-01-12 10:37:10.784417+00	\N	t	2026-01-12 10:37:10.784417+00
1	EQA--JXG8VSyBJmLMqb2J2t4Pya0TS9SXHh7vHh8Iez25sLp	100.00	admin	2026-01-12 01:11:44.09235+00	\N	t	2026-01-12 10:37:10.782164+00
\.


--
-- Data for Name: wallet_access_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wallet_access_log (id, wallet_address, operation, success, details, accessed_at) FROM stdin;
\.


--
-- Data for Name: withdrawal_locks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.withdrawal_locks (id, task_id, worker_wallet, amount_gstd, status, approved_by, approved_at, created_at, notes) FROM stdin;
\.


--
-- Data for Name: worker_rewards; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.worker_rewards (id, worker_address, task_id, amount, status, created_at) FROM stdin;
\.


--
-- Name: devices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.devices_id_seq', 1, false);


--
-- Name: error_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.error_logs_id_seq', 1, false);


--
-- Name: failed_payouts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.failed_payouts_id_seq', 1, false);


--
-- Name: golden_reserve_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.golden_reserve_log_id_seq', 1, false);


--
-- Name: network_stats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.network_stats_id_seq', 1, false);


--
-- Name: nodes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.nodes_id_seq', 1, false);


--
-- Name: payout_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payout_transactions_id_seq', 1, false);


--
-- Name: pool_stats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pool_stats_id_seq', 1, false);


--
-- Name: processed_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.processed_payments_id_seq', 1, false);


--
-- Name: schema_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.schema_migrations_id_seq', 6, true);


--
-- Name: transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.transactions_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 5, true);


--
-- Name: wallet_access_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.wallet_access_log_id_seq', 1, false);


--
-- Name: withdrawal_locks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.withdrawal_locks_id_seq', 1, false);


--
-- Name: worker_rewards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.worker_rewards_id_seq', 1, false);


--
-- Name: devices devices_device_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_device_id_key UNIQUE (device_id);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (id);


--
-- Name: error_logs error_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.error_logs
    ADD CONSTRAINT error_logs_pkey PRIMARY KEY (id);


--
-- Name: failed_payouts failed_payouts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_payouts
    ADD CONSTRAINT failed_payouts_pkey PRIMARY KEY (id);


--
-- Name: golden_reserve_log golden_reserve_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.golden_reserve_log
    ADD CONSTRAINT golden_reserve_log_pkey PRIMARY KEY (id);


--
-- Name: jetton_balances jetton_balances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jetton_balances
    ADD CONSTRAINT jetton_balances_pkey PRIMARY KEY (address);


--
-- Name: network_stats network_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.network_stats
    ADD CONSTRAINT network_stats_pkey PRIMARY KEY (id);


--
-- Name: node_efficiency node_efficiency_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.node_efficiency
    ADD CONSTRAINT node_efficiency_pkey PRIMARY KEY (node_id);


--
-- Name: nodes nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodes
    ADD CONSTRAINT nodes_pkey PRIMARY KEY (id);


--
-- Name: payout_transactions payout_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payout_transactions
    ADD CONSTRAINT payout_transactions_pkey PRIMARY KEY (id);


--
-- Name: pool_stats pool_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pool_stats
    ADD CONSTRAINT pool_stats_pkey PRIMARY KEY (id);


--
-- Name: processed_payments processed_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.processed_payments
    ADD CONSTRAINT processed_payments_pkey PRIMARY KEY (id);


--
-- Name: processed_payments processed_payments_tx_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.processed_payments
    ADD CONSTRAINT processed_payments_tx_hash_key UNIQUE (tx_hash);


--
-- Name: schema_migrations schema_migrations_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_name_key UNIQUE (name);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (task_id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_tx_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_tx_hash_key UNIQUE (tx_hash);


--
-- Name: user_balances user_balances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_balances
    ADD CONSTRAINT user_balances_pkey PRIMARY KEY (address);


--
-- Name: user_stats user_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_stats
    ADD CONSTRAINT user_stats_pkey PRIMARY KEY (address);


--
-- Name: users users_address_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_address_key UNIQUE (address);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: wallet_access_log wallet_access_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallet_access_log
    ADD CONSTRAINT wallet_access_log_pkey PRIMARY KEY (id);


--
-- Name: withdrawal_locks withdrawal_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.withdrawal_locks
    ADD CONSTRAINT withdrawal_locks_pkey PRIMARY KEY (id);


--
-- Name: withdrawal_locks withdrawal_locks_task_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.withdrawal_locks
    ADD CONSTRAINT withdrawal_locks_task_id_key UNIQUE (task_id);


--
-- Name: worker_rewards worker_rewards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.worker_rewards
    ADD CONSTRAINT worker_rewards_pkey PRIMARY KEY (id);


--
-- Name: idx_devices_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_devices_active ON public.devices USING btree (is_active) WHERE (is_active = true);


--
-- Name: idx_devices_device_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_devices_device_id ON public.devices USING btree (device_id);


--
-- Name: idx_devices_last_seen; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_devices_last_seen ON public.devices USING btree (last_seen_at);


--
-- Name: idx_devices_wallet_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_devices_wallet_active ON public.devices USING btree (wallet_address, is_active);


--
-- Name: idx_devices_wallet_address; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_devices_wallet_address ON public.devices USING btree (wallet_address);


--
-- Name: idx_error_logs_severity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_error_logs_severity ON public.error_logs USING btree (severity);


--
-- Name: idx_failed_payouts_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_failed_payouts_created_at ON public.failed_payouts USING btree (created_at DESC);


--
-- Name: idx_failed_payouts_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_failed_payouts_status ON public.failed_payouts USING btree (status, retry_count);


--
-- Name: idx_failed_payouts_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_failed_payouts_task_id ON public.failed_payouts USING btree (task_id);


--
-- Name: idx_nodes_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_nodes_owner ON public.nodes USING btree (owner_address);


--
-- Name: idx_nodes_wallet; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_nodes_wallet ON public.nodes USING btree (wallet_address);


--
-- Name: idx_payout_task; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payout_task ON public.payout_transactions USING btree (task_id);


--
-- Name: idx_processed_payments_processed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_processed_payments_processed_at ON public.processed_payments USING btree (processed_at DESC);


--
-- Name: idx_processed_payments_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_processed_payments_task_id ON public.processed_payments USING btree (task_id);


--
-- Name: idx_processed_payments_tx_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_processed_payments_tx_hash ON public.processed_payments USING btree (tx_hash);


--
-- Name: idx_tasks_assigned_device; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tasks_assigned_device ON public.tasks USING btree (assigned_device);


--
-- Name: idx_tasks_completed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tasks_completed_at ON public.tasks USING btree (completed_at);


--
-- Name: idx_tasks_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tasks_created_at ON public.tasks USING btree (created_at);


--
-- Name: idx_tasks_device_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tasks_device_id ON public.tasks USING btree (device_id);


--
-- Name: idx_tasks_escrow; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tasks_escrow ON public.tasks USING btree (escrow_status);


--
-- Name: idx_tasks_payout_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tasks_payout_status ON public.tasks USING btree (executor_payout_status);


--
-- Name: idx_tasks_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tasks_status ON public.tasks USING btree (status);


--
-- Name: idx_tasks_status_timeout; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tasks_status_timeout ON public.tasks USING btree (status, timeout_at) WHERE (status = 'assigned'::text);


--
-- Name: idx_tasks_timeout; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tasks_timeout ON public.tasks USING btree (status, timeout_at) WHERE (status = 'assigned'::text);


--
-- Name: idx_wallet_access_log_accessed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wallet_access_log_accessed_at ON public.wallet_access_log USING btree (accessed_at);


--
-- Name: idx_wallet_access_log_address; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wallet_access_log_address ON public.wallet_access_log USING btree (wallet_address);


--
-- Name: idx_wallet_access_log_success; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wallet_access_log_success ON public.wallet_access_log USING btree (success);


--
-- Name: idx_withdrawal_locks_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_withdrawal_locks_created ON public.withdrawal_locks USING btree (created_at DESC);


--
-- Name: idx_withdrawal_locks_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_withdrawal_locks_status ON public.withdrawal_locks USING btree (status);


--
-- Name: idx_withdrawal_locks_worker; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_withdrawal_locks_worker ON public.withdrawal_locks USING btree (worker_wallet);


--
-- PostgreSQL database dump complete
--

\unrestrict pVpwGXJ0S2XgdAPgts1XOPSe7Ldzo1iN8pXS0j4Tc2YsWHQ7RDcW8fzCF3ufhVg

