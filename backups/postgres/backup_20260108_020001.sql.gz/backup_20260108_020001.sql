--
-- PostgreSQL database dump
--

\restrict ccXHhe9vYvNcNqpVispyXEGEimDjqc6uZk8BhEwbI7Klc32WXMoIn71J1T7TuDl

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: device_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.device_metrics (
    metric_id uuid NOT NULL,
    device_id character varying(255) NOT NULL,
    metric_type character varying(20) NOT NULL,
    metric_value numeric(10,4) NOT NULL,
    recorded_at timestamp without time zone NOT NULL
);


ALTER TABLE public.device_metrics OWNER TO postgres;

--
-- Name: devices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.devices (
    device_id character varying(255) NOT NULL,
    wallet_address character varying(100) NOT NULL,
    device_type character varying(20) NOT NULL,
    reputation numeric(5,4) DEFAULT 0.5 NOT NULL,
    total_tasks integer DEFAULT 0 NOT NULL,
    successful_tasks integer DEFAULT 0 NOT NULL,
    failed_tasks integer DEFAULT 0 NOT NULL,
    total_energy_consumed integer DEFAULT 0 NOT NULL,
    average_response_time_ms integer DEFAULT 0 NOT NULL,
    cached_models text[],
    last_seen_at timestamp without time zone NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    slashing_count integer DEFAULT 0 NOT NULL,
    trust_score numeric(5,4) DEFAULT 0.1,
    region character varying(10) DEFAULT 'unknown'::character varying,
    latency_fingerprint integer DEFAULT 0,
    accuracy_score numeric(5,4) DEFAULT 0.5,
    latency_score numeric(5,4) DEFAULT 0.5,
    stability_score numeric(5,4) DEFAULT 0.5,
    last_reputation_update timestamp without time zone
);


ALTER TABLE public.devices OWNER TO postgres;

--
-- Name: failed_payouts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.failed_payouts (
    id integer NOT NULL,
    task_id character varying(255) NOT NULL,
    payout_type character varying(20) NOT NULL,
    recipient_address character varying(48),
    amount_gstd numeric(18,9) NOT NULL,
    error_message text,
    retry_count integer DEFAULT 0 NOT NULL,
    max_retries integer DEFAULT 5 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    last_retry_at timestamp without time zone,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL
);


ALTER TABLE public.failed_payouts OWNER TO postgres;

--
-- Name: failed_payouts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.failed_payouts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.failed_payouts_id_seq OWNER TO postgres;

--
-- Name: failed_payouts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.failed_payouts_id_seq OWNED BY public.failed_payouts.id;


--
-- Name: golden_reserve_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.golden_reserve_log (
    id integer NOT NULL,
    task_id character varying(255) NOT NULL,
    gstd_amount numeric(18,9) NOT NULL,
    xaut_amount numeric(18,9),
    treasury_wallet character varying(48) NOT NULL,
    swap_tx_hash character varying(64),
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.golden_reserve_log OWNER TO postgres;

--
-- Name: golden_reserve_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.golden_reserve_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.golden_reserve_log_id_seq OWNER TO postgres;

--
-- Name: golden_reserve_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.golden_reserve_log_id_seq OWNED BY public.golden_reserve_log.id;


--
-- Name: moving_entropy_stats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.moving_entropy_stats (
    operation_id character varying(50) NOT NULL,
    recent_errors_json jsonb DEFAULT '[]'::jsonb,
    current_temp numeric(10,6) DEFAULT 0.1
);


ALTER TABLE public.moving_entropy_stats OWNER TO postgres;

--
-- Name: network_health; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.network_health (
    id integer NOT NULL,
    avg_latency_ms integer,
    global_entropy numeric(5,4),
    active_nodes integer,
    recorded_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.network_health OWNER TO postgres;

--
-- Name: network_health_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.network_health_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.network_health_id_seq OWNER TO postgres;

--
-- Name: network_health_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.network_health_id_seq OWNED BY public.network_health.id;


--
-- Name: network_physics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.network_physics (
    id integer NOT NULL,
    temperature numeric(10,6),
    pressure numeric(10,6),
    entropy_gradient numeric(10,6),
    recorded_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.network_physics OWNER TO postgres;

--
-- Name: network_physics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.network_physics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.network_physics_id_seq OWNER TO postgres;

--
-- Name: network_physics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.network_physics_id_seq OWNED BY public.network_physics.id;


--
-- Name: nodes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.nodes (
    id character varying(255) NOT NULL,
    wallet_address character varying(100) NOT NULL,
    name character varying(255) NOT NULL,
    status character varying(20) DEFAULT 'offline'::character varying NOT NULL,
    cpu_model character varying(255),
    ram_gb integer,
    last_seen timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.nodes OWNER TO postgres;

--
-- Name: operation_entropy; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.operation_entropy (
    operation_id character varying(50) NOT NULL,
    total_executions bigint DEFAULT 0,
    collision_count bigint DEFAULT 0,
    entropy_score numeric(5,4) DEFAULT 0.1,
    last_updated timestamp without time zone DEFAULT now()
);


ALTER TABLE public.operation_entropy OWNER TO postgres;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    payment_id uuid NOT NULL,
    task_id uuid NOT NULL,
    assignment_id uuid NOT NULL,
    device_address character varying(48) NOT NULL,
    amount_ton numeric(18,9) NOT NULL,
    base_reward numeric(18,9) NOT NULL,
    energy_bonus numeric(18,9) DEFAULT 0 NOT NULL,
    time_bonus numeric(18,9) DEFAULT 0 NOT NULL,
    reputation_multiplier numeric(5,4) DEFAULT 1.0 NOT NULL,
    tx_hash character varying(64),
    tx_status character varying(20) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    confirmed_at timestamp without time zone
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: processed_payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.processed_payments (
    id integer NOT NULL,
    tx_hash character varying(64) NOT NULL,
    task_id character varying(255),
    processed_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.processed_payments OWNER TO postgres;

--
-- Name: processed_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.processed_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.processed_payments_id_seq OWNER TO postgres;

--
-- Name: processed_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.processed_payments_id_seq OWNED BY public.processed_payments.id;


--
-- Name: requesters; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.requesters (
    requester_address character varying(48) NOT NULL,
    gstd_balance numeric(18,9) DEFAULT 0 NOT NULL,
    reputation numeric(5,4) DEFAULT 0.5 NOT NULL,
    total_tasks_created integer DEFAULT 0 NOT NULL,
    total_tasks_completed integer DEFAULT 0 NOT NULL,
    total_ton_spent numeric(18,9) DEFAULT 0 NOT NULL,
    average_validation_success_rate numeric(5,4) DEFAULT 1.0 NOT NULL,
    timely_payments_count integer DEFAULT 0 NOT NULL,
    last_activity_at timestamp without time zone NOT NULL
);


ALTER TABLE public.requesters OWNER TO postgres;

--
-- Name: slashings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.slashings (
    slashing_id uuid NOT NULL,
    device_id character varying(255) NOT NULL,
    task_id uuid,
    assignment_id uuid,
    reason character varying(50) NOT NULL,
    severity character varying(10) NOT NULL,
    amount_gstd numeric(18,9) NOT NULL,
    slashed_at timestamp without time zone NOT NULL
);


ALTER TABLE public.slashings OWNER TO postgres;

--
-- Name: task_assignments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_assignments (
    assignment_id uuid NOT NULL,
    task_id uuid NOT NULL,
    device_id character varying(255) NOT NULL,
    assigned_at timestamp without time zone NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    status character varying(20) NOT NULL,
    result_data jsonb,
    proof_signature character varying(255),
    proof_timestamp bigint,
    proof_energy_consumed integer,
    proof_execution_time_ms integer,
    validation_status character varying(20),
    validation_method character varying(20),
    payment_tx_hash character varying(64),
    payment_status character varying(20)
);


ALTER TABLE public.task_assignments OWNER TO postgres;

--
-- Name: task_queue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_queue (
    queue_id uuid NOT NULL,
    task_id uuid NOT NULL,
    priority_score numeric(10,6) NOT NULL,
    queued_at timestamp without time zone NOT NULL,
    assigned_at timestamp without time zone,
    retry_count integer DEFAULT 0 NOT NULL,
    status character varying(20) NOT NULL
);


ALTER TABLE public.task_queue OWNER TO postgres;

--
-- Name: tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tasks (
    task_id uuid NOT NULL,
    requester_address character varying(48) NOT NULL,
    task_type character varying(20) NOT NULL,
    operation character varying(50) NOT NULL,
    model character varying(50),
    input_source character varying(10) NOT NULL,
    input_hash character varying(255),
    input_data text,
    constraints_time_limit_sec integer NOT NULL,
    constraints_max_energy_mwh integer NOT NULL,
    labor_compensation_ton numeric(18,9) NOT NULL,
    validation_method character varying(20) NOT NULL,
    certainty_gravity_score numeric(10,6) NOT NULL,
    status character varying(20) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    assigned_at timestamp without time zone,
    completed_at timestamp without time zone,
    escrow_address character varying(48) NOT NULL,
    escrow_amount_ton numeric(18,9) NOT NULL,
    assigned_device character varying(255),
    timeout_at timestamp without time zone,
    result_data text,
    result_nonce character varying(255),
    result_proof character varying(255),
    execution_time_ms integer,
    result_submitted_at timestamp without time zone,
    platform_fee_ton numeric(18,9),
    executor_reward_ton numeric(18,9),
    escrow_status character varying(20) DEFAULT 'none'::character varying,
    total_reward_pool numeric(18,9),
    min_trust_score numeric(5,4) DEFAULT 0.0,
    geo_restriction character varying(10)[],
    is_private boolean DEFAULT false,
    redundancy_factor integer DEFAULT 1,
    confidence_depth integer DEFAULT 1,
    confidence_score numeric(5,4) DEFAULT 0.0,
    priority_tier character varying(10) DEFAULT 'standard'::character varying,
    min_reward_floor numeric(18,9) DEFAULT 0.0001,
    is_spot_check boolean DEFAULT false,
    gravity_score numeric(18,9) DEFAULT 0.0,
    entropy_snapshot numeric(5,4) DEFAULT 0.0,
    required_certainty_level numeric(5,4) DEFAULT 0.95,
    computational_pressure_impact numeric(10,6) DEFAULT 0.0,
    creator_wallet character varying(48),
    budget_gstd numeric(18,9),
    reward_gstd numeric(18,9),
    deposit_id character varying(64),
    payload jsonb,
    payment_memo character varying(255),
    priority_score numeric(10,6) DEFAULT 0.0
);


ALTER TABLE public.tasks OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    wallet_address character varying(100) NOT NULL,
    balance numeric(18,9) DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: validations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.validations (
    validation_id uuid NOT NULL,
    task_id uuid NOT NULL,
    assignment_id uuid NOT NULL,
    validation_method character varying(20) NOT NULL,
    reference_result jsonb,
    majority_results jsonb[],
    ai_check_confidence numeric(5,4),
    human_check_result boolean,
    human_checker_address character varying(48),
    validation_result character varying(20) NOT NULL,
    validated_at timestamp without time zone
);


ALTER TABLE public.validations OWNER TO postgres;

--
-- Name: wallet_access_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wallet_access_log (
    id integer NOT NULL,
    wallet_address character varying(66) NOT NULL,
    operation character varying(50) NOT NULL,
    success boolean NOT NULL,
    details text,
    accessed_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.wallet_access_log OWNER TO postgres;

--
-- Name: wallet_access_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.wallet_access_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wallet_access_log_id_seq OWNER TO postgres;

--
-- Name: wallet_access_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.wallet_access_log_id_seq OWNED BY public.wallet_access_log.id;


--
-- Name: withdrawal_locks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.withdrawal_locks (
    id integer NOT NULL,
    task_id character varying(255) NOT NULL,
    worker_wallet character varying(48) NOT NULL,
    amount_gstd numeric(18,9) NOT NULL,
    status character varying(20) DEFAULT 'pending_approval'::character varying NOT NULL,
    approved_by character varying(48),
    approved_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    notes text
);


ALTER TABLE public.withdrawal_locks OWNER TO postgres;

--
-- Name: withdrawal_locks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.withdrawal_locks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.withdrawal_locks_id_seq OWNER TO postgres;

--
-- Name: withdrawal_locks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.withdrawal_locks_id_seq OWNED BY public.withdrawal_locks.id;


--
-- Name: failed_payouts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_payouts ALTER COLUMN id SET DEFAULT nextval('public.failed_payouts_id_seq'::regclass);


--
-- Name: golden_reserve_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.golden_reserve_log ALTER COLUMN id SET DEFAULT nextval('public.golden_reserve_log_id_seq'::regclass);


--
-- Name: network_health id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.network_health ALTER COLUMN id SET DEFAULT nextval('public.network_health_id_seq'::regclass);


--
-- Name: network_physics id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.network_physics ALTER COLUMN id SET DEFAULT nextval('public.network_physics_id_seq'::regclass);


--
-- Name: processed_payments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.processed_payments ALTER COLUMN id SET DEFAULT nextval('public.processed_payments_id_seq'::regclass);


--
-- Name: wallet_access_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wallet_access_log ALTER COLUMN id SET DEFAULT nextval('public.wallet_access_log_id_seq'::regclass);


--
-- Name: withdrawal_locks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.withdrawal_locks ALTER COLUMN id SET DEFAULT nextval('public.withdrawal_locks_id_seq'::regclass);


--
-- Data for Name: device_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.device_metrics (metric_id, device_id, metric_type, metric_value, recorded_at) FROM stdin;
\.


--
-- Data for Name: devices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.devices (device_id, wallet_address, device_type, reputation, total_tasks, successful_tasks, failed_tasks, total_energy_consumed, average_response_time_ms, cached_models, last_seen_at, is_active, slashing_count, trust_score, region, latency_fingerprint, accuracy_score, latency_score, stability_score, last_reputation_update) FROM stdin;
\.


--
-- Data for Name: failed_payouts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.failed_payouts (id, task_id, payout_type, recipient_address, amount_gstd, error_message, retry_count, max_retries, created_at, last_retry_at, status) FROM stdin;
\.


--
-- Data for Name: golden_reserve_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.golden_reserve_log (id, task_id, gstd_amount, xaut_amount, treasury_wallet, swap_tx_hash, "timestamp") FROM stdin;
\.


--
-- Data for Name: moving_entropy_stats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.moving_entropy_stats (operation_id, recent_errors_json, current_temp) FROM stdin;
\.


--
-- Data for Name: network_health; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.network_health (id, avg_latency_ms, global_entropy, active_nodes, recorded_at) FROM stdin;
\.


--
-- Data for Name: network_physics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.network_physics (id, temperature, pressure, entropy_gradient, recorded_at) FROM stdin;
\.


--
-- Data for Name: nodes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.nodes (id, wallet_address, name, status, cpu_model, ram_gb, last_seen, created_at, updated_at) FROM stdin;
579f4958-25e4-49b8-80a2-392a51456eea	0:a45c594d46cb9b529ed487b960fd2714a8b0a27dfd5008bb1d414d1aee4a61a9	Admin	offline	\N	\N	2026-01-07 18:28:52.223122	2026-01-07 18:28:52.223122	2026-01-07 18:28:52.223122
\.


--
-- Data for Name: operation_entropy; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.operation_entropy (operation_id, total_executions, collision_count, entropy_score, last_updated) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (payment_id, task_id, assignment_id, device_address, amount_ton, base_reward, energy_bonus, time_bonus, reputation_multiplier, tx_hash, tx_status, created_at, confirmed_at) FROM stdin;
\.


--
-- Data for Name: processed_payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.processed_payments (id, tx_hash, task_id, processed_at) FROM stdin;
\.


--
-- Data for Name: requesters; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.requesters (requester_address, gstd_balance, reputation, total_tasks_created, total_tasks_completed, total_ton_spent, average_validation_success_rate, timely_payments_count, last_activity_at) FROM stdin;
\.


--
-- Data for Name: slashings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.slashings (slashing_id, device_id, task_id, assignment_id, reason, severity, amount_gstd, slashed_at) FROM stdin;
\.


--
-- Data for Name: task_assignments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_assignments (assignment_id, task_id, device_id, assigned_at, started_at, completed_at, status, result_data, proof_signature, proof_timestamp, proof_energy_consumed, proof_execution_time_ms, validation_status, validation_method, payment_tx_hash, payment_status) FROM stdin;
\.


--
-- Data for Name: task_queue; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_queue (queue_id, task_id, priority_score, queued_at, assigned_at, retry_count, status) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tasks (task_id, requester_address, task_type, operation, model, input_source, input_hash, input_data, constraints_time_limit_sec, constraints_max_energy_mwh, labor_compensation_ton, validation_method, certainty_gravity_score, status, created_at, assigned_at, completed_at, escrow_address, escrow_amount_ton, assigned_device, timeout_at, result_data, result_nonce, result_proof, execution_time_ms, result_submitted_at, platform_fee_ton, executor_reward_ton, escrow_status, total_reward_pool, min_trust_score, geo_restriction, is_private, redundancy_factor, confidence_depth, confidence_score, priority_tier, min_reward_floor, is_spot_check, gravity_score, entropy_snapshot, required_certainty_level, computational_pressure_impact, creator_wallet, budget_gstd, reward_gstd, deposit_id, payload, payment_memo, priority_score) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (wallet_address, balance, created_at, updated_at) FROM stdin;
0:a45c594d46cb9b529ed487b960fd2714a8b0a27dfd5008bb1d414d1aee4a61a9	0.000000000	2026-01-07 18:18:52.741574	2026-01-07 18:18:52.741574
\.


--
-- Data for Name: validations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.validations (validation_id, task_id, assignment_id, validation_method, reference_result, majority_results, ai_check_confidence, human_check_result, human_checker_address, validation_result, validated_at) FROM stdin;
\.


--
-- Data for Name: wallet_access_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.wallet_access_log (id, wallet_address, operation, success, details, accessed_at) FROM stdin;
\.


--
-- Data for Name: withdrawal_locks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.withdrawal_locks (id, task_id, worker_wallet, amount_gstd, status, approved_by, approved_at, created_at, notes) FROM stdin;
\.


--
-- Name: failed_payouts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.failed_payouts_id_seq', 1, false);


--
-- Name: golden_reserve_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.golden_reserve_log_id_seq', 1, false);


--
-- Name: network_health_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.network_health_id_seq', 1, false);


--
-- Name: network_physics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.network_physics_id_seq', 1, false);


--
-- Name: processed_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.processed_payments_id_seq', 1, false);


--
-- Name: wallet_access_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.wallet_access_log_id_seq', 1, false);


--
-- Name: withdrawal_locks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.withdrawal_locks_id_seq', 1, false);


--
-- Name: device_metrics device_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.device_metrics
    ADD CONSTRAINT device_metrics_pkey PRIMARY KEY (metric_id);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (device_id);


--
-- Name: failed_payouts failed_payouts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_payouts
    ADD CONSTRAINT failed_payouts_pkey PRIMARY KEY (id);


--
-- Name: golden_reserve_log golden_reserve_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.golden_reserve_log
    ADD CONSTRAINT golden_reserve_log_pkey PRIMARY KEY (id);


--
-- Name: moving_entropy_stats moving_entropy_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.moving_entropy_stats
    ADD CONSTRAINT moving_entropy_stats_pkey PRIMARY KEY (operation_id);


--
-- Name: network_health network_health_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.network_health
    ADD CONSTRAINT network_health_pkey PRIMARY KEY (id);


--
-- Name: network_physics network_physics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.network_physics
    ADD CONSTRAINT network_physics_pkey PRIMARY KEY (id);


--
-- Name: nodes nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nodes
    ADD CONSTRAINT nodes_pkey PRIMARY KEY (id);


--
-- Name: operation_entropy operation_entropy_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operation_entropy
    ADD CONSTRAINT operation_entropy_pkey PRIMARY KEY (operation_id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (payment_id);


--
-- Name: payments payments_tx_hash_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_tx_hash_key UNIQUE (tx_hash);


--
-- Name: processed_payments processed_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.processed_payments
    ADD CONSTRAINT processed_payments_pkey PRIMARY KEY (id);


--
-- Name: processed_payments processed_payments_tx_hash_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.processed_payments
    ADD CONSTRAINT processed_payments_tx_hash_key UNIQUE (tx_hash);


--
-- Name: requesters requesters_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.requesters
    ADD CONSTRAINT requesters_pkey PRIMARY KEY (requester_address);


--
-- Name: slashings slashings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.slashings
    ADD CONSTRAINT slashings_pkey PRIMARY KEY (slashing_id);


--
-- Name: task_assignments task_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_assignments
    ADD CONSTRAINT task_assignments_pkey PRIMARY KEY (assignment_id);


--
-- Name: task_queue task_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_queue
    ADD CONSTRAINT task_queue_pkey PRIMARY KEY (queue_id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (task_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (wallet_address);


--
-- Name: validations validations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.validations
    ADD CONSTRAINT validations_pkey PRIMARY KEY (validation_id);


--
-- Name: wallet_access_log wallet_access_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wallet_access_log
    ADD CONSTRAINT wallet_access_log_pkey PRIMARY KEY (id);


--
-- Name: withdrawal_locks withdrawal_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.withdrawal_locks
    ADD CONSTRAINT withdrawal_locks_pkey PRIMARY KEY (id);


--
-- Name: withdrawal_locks withdrawal_locks_task_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.withdrawal_locks
    ADD CONSTRAINT withdrawal_locks_task_id_key UNIQUE (task_id);


--
-- Name: idx_assignments_assigned_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_assignments_assigned_at ON public.task_assignments USING btree (assigned_at);


--
-- Name: idx_assignments_device; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_assignments_device ON public.task_assignments USING btree (device_id);


--
-- Name: idx_assignments_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_assignments_status ON public.task_assignments USING btree (status);


--
-- Name: idx_assignments_task; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_assignments_task ON public.task_assignments USING btree (task_id);


--
-- Name: idx_devices_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_devices_active ON public.devices USING btree (is_active, reputation DESC);


--
-- Name: idx_devices_last_seen; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_devices_last_seen ON public.devices USING btree (last_seen_at);


--
-- Name: idx_devices_reputation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_devices_reputation ON public.devices USING btree (reputation DESC);


--
-- Name: idx_devices_trust_region; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_devices_trust_region ON public.devices USING btree (trust_score DESC, region);


--
-- Name: idx_devices_vector; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_devices_vector ON public.devices USING btree (accuracy_score DESC, latency_score DESC, stability_score DESC);


--
-- Name: idx_failed_payouts_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_failed_payouts_created_at ON public.failed_payouts USING btree (created_at DESC);


--
-- Name: idx_failed_payouts_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_failed_payouts_status ON public.failed_payouts USING btree (status, retry_count);


--
-- Name: idx_failed_payouts_task_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_failed_payouts_task_id ON public.failed_payouts USING btree (task_id);


--
-- Name: idx_golden_reserve_task_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_golden_reserve_task_id ON public.golden_reserve_log USING btree (task_id);


--
-- Name: idx_golden_reserve_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_golden_reserve_timestamp ON public.golden_reserve_log USING btree ("timestamp" DESC);


--
-- Name: idx_golden_reserve_treasury; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_golden_reserve_treasury ON public.golden_reserve_log USING btree (treasury_wallet);


--
-- Name: idx_metrics_device_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_metrics_device_type ON public.device_metrics USING btree (device_id, metric_type, recorded_at DESC);


--
-- Name: idx_nodes_last_seen; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_nodes_last_seen ON public.nodes USING btree (last_seen DESC);


--
-- Name: idx_nodes_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_nodes_status ON public.nodes USING btree (status);


--
-- Name: idx_nodes_wallet_address; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_nodes_wallet_address ON public.nodes USING btree (wallet_address);


--
-- Name: idx_operation_entropy; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_operation_entropy ON public.operation_entropy USING btree (entropy_score DESC);


--
-- Name: idx_payments_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payments_created_at ON public.payments USING btree (created_at);


--
-- Name: idx_payments_device; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payments_device ON public.payments USING btree (device_address);


--
-- Name: idx_payments_tx_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payments_tx_status ON public.payments USING btree (tx_status);


--
-- Name: idx_processed_payments_processed_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_processed_payments_processed_at ON public.processed_payments USING btree (processed_at DESC);


--
-- Name: idx_processed_payments_task_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_processed_payments_task_id ON public.processed_payments USING btree (task_id);


--
-- Name: idx_processed_payments_tx_hash; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_processed_payments_tx_hash ON public.processed_payments USING btree (tx_hash);


--
-- Name: idx_queue_priority; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_queue_priority ON public.task_queue USING btree (status, priority_score DESC, queued_at);


--
-- Name: idx_queue_task; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_queue_task ON public.task_queue USING btree (task_id);


--
-- Name: idx_requesters_balance; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_requesters_balance ON public.requesters USING btree (gstd_balance DESC);


--
-- Name: idx_requesters_reputation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_requesters_reputation ON public.requesters USING btree (reputation DESC);


--
-- Name: idx_slashings_device; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_slashings_device ON public.slashings USING btree (device_id);


--
-- Name: idx_slashings_reason; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_slashings_reason ON public.slashings USING btree (reason);


--
-- Name: idx_tasks_assigned_device; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tasks_assigned_device ON public.tasks USING btree (assigned_device);


--
-- Name: idx_tasks_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tasks_created_at ON public.tasks USING btree (created_at);


--
-- Name: idx_tasks_deposit_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tasks_deposit_id ON public.tasks USING btree (deposit_id) WHERE (deposit_id IS NOT NULL);


--
-- Name: idx_tasks_depth; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tasks_depth ON public.tasks USING btree (status, confidence_depth);


--
-- Name: idx_tasks_escrow; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tasks_escrow ON public.tasks USING btree (escrow_status);


--
-- Name: idx_tasks_gravity; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tasks_gravity ON public.tasks USING btree (status, gravity_score DESC);


--
-- Name: idx_tasks_payment_memo; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tasks_payment_memo ON public.tasks USING btree (payment_memo) WHERE (payment_memo IS NOT NULL);


--
-- Name: idx_tasks_physics; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tasks_physics ON public.tasks USING btree (status, certainty_gravity_score DESC, labor_compensation_ton DESC);


--
-- Name: idx_tasks_priority_bucket; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tasks_priority_bucket ON public.tasks USING btree (status, certainty_gravity_score DESC, min_trust_score);


--
-- Name: idx_tasks_requester; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tasks_requester ON public.tasks USING btree (requester_address);


--
-- Name: idx_tasks_status_creator; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tasks_status_creator ON public.tasks USING btree (status, creator_wallet);


--
-- Name: idx_tasks_timeout; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tasks_timeout ON public.tasks USING btree (status, timeout_at) WHERE ((status)::text = 'assigned'::text);


--
-- Name: idx_users_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_created_at ON public.users USING btree (created_at DESC);


--
-- Name: idx_users_wallet_address; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_wallet_address ON public.users USING btree (wallet_address);


--
-- Name: idx_validations_result; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_validations_result ON public.validations USING btree (validation_result);


--
-- Name: idx_validations_task; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_validations_task ON public.validations USING btree (task_id);


--
-- Name: idx_wallet_access_log_accessed_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_wallet_access_log_accessed_at ON public.wallet_access_log USING btree (accessed_at);


--
-- Name: idx_wallet_access_log_address; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_wallet_access_log_address ON public.wallet_access_log USING btree (wallet_address);


--
-- Name: idx_wallet_access_log_success; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_wallet_access_log_success ON public.wallet_access_log USING btree (success);


--
-- Name: idx_withdrawal_locks_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_withdrawal_locks_created ON public.withdrawal_locks USING btree (created_at DESC);


--
-- Name: idx_withdrawal_locks_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_withdrawal_locks_status ON public.withdrawal_locks USING btree (status);


--
-- Name: idx_withdrawal_locks_worker; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_withdrawal_locks_worker ON public.withdrawal_locks USING btree (worker_wallet);


--
-- Name: device_metrics device_metrics_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.device_metrics
    ADD CONSTRAINT device_metrics_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(device_id);


--
-- Name: nodes nodes_wallet_address_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nodes
    ADD CONSTRAINT nodes_wallet_address_fkey FOREIGN KEY (wallet_address) REFERENCES public.users(wallet_address) ON DELETE CASCADE;


--
-- Name: payments payments_assignment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_assignment_id_fkey FOREIGN KEY (assignment_id) REFERENCES public.task_assignments(assignment_id);


--
-- Name: payments payments_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(task_id);


--
-- Name: slashings slashings_assignment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.slashings
    ADD CONSTRAINT slashings_assignment_id_fkey FOREIGN KEY (assignment_id) REFERENCES public.task_assignments(assignment_id);


--
-- Name: slashings slashings_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.slashings
    ADD CONSTRAINT slashings_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(device_id);


--
-- Name: slashings slashings_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.slashings
    ADD CONSTRAINT slashings_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(task_id);


--
-- Name: task_assignments task_assignments_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_assignments
    ADD CONSTRAINT task_assignments_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(device_id);


--
-- Name: task_assignments task_assignments_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_assignments
    ADD CONSTRAINT task_assignments_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(task_id);


--
-- Name: task_queue task_queue_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_queue
    ADD CONSTRAINT task_queue_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(task_id);


--
-- Name: validations validations_assignment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.validations
    ADD CONSTRAINT validations_assignment_id_fkey FOREIGN KEY (assignment_id) REFERENCES public.task_assignments(assignment_id);


--
-- Name: validations validations_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.validations
    ADD CONSTRAINT validations_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(task_id);


--
-- PostgreSQL database dump complete
--

\unrestrict ccXHhe9vYvNcNqpVispyXEGEimDjqc6uZk8BhEwbI7Klc32WXMoIn71J1T7TuDl

