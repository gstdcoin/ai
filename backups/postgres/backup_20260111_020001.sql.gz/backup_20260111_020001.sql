--
-- PostgreSQL database dump
--

\restrict uMQo6UIIUmeiPCP35OCHaog4aXApixrrXhbfUcq4Hcrk4d8gQBH3cTLHzJeeyI5

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: device_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.device_metrics (
    metric_id uuid NOT NULL,
    device_id character varying(255) NOT NULL,
    metric_type character varying(20) NOT NULL,
    metric_value numeric(10,4) NOT NULL,
    recorded_at timestamp without time zone NOT NULL
);


ALTER TABLE public.device_metrics OWNER TO postgres;

--
-- Name: devices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.devices (
    device_id character varying(255) NOT NULL,
    wallet_address character varying(48) NOT NULL,
    device_type character varying(20) NOT NULL,
    reputation numeric(5,4) DEFAULT 0.5 NOT NULL,
    total_tasks integer DEFAULT 0 NOT NULL,
    successful_tasks integer DEFAULT 0 NOT NULL,
    failed_tasks integer DEFAULT 0 NOT NULL,
    total_energy_consumed integer DEFAULT 0 NOT NULL,
    average_response_time_ms integer DEFAULT 0 NOT NULL,
    cached_models text[],
    last_seen_at timestamp without time zone NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    slashing_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.devices OWNER TO postgres;

--
-- Name: failed_payouts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.failed_payouts (
    id integer NOT NULL,
    task_id character varying(255) NOT NULL,
    payout_type character varying(20) NOT NULL,
    recipient_address character varying(48),
    amount_gstd numeric(18,9) NOT NULL,
    error_message text,
    retry_count integer DEFAULT 0 NOT NULL,
    max_retries integer DEFAULT 5 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    last_retry_at timestamp without time zone,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL
);


ALTER TABLE public.failed_payouts OWNER TO postgres;

--
-- Name: failed_payouts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.failed_payouts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.failed_payouts_id_seq OWNER TO postgres;

--
-- Name: failed_payouts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.failed_payouts_id_seq OWNED BY public.failed_payouts.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    payment_id uuid NOT NULL,
    task_id uuid NOT NULL,
    assignment_id uuid NOT NULL,
    device_address character varying(48) NOT NULL,
    amount_ton numeric(18,9) NOT NULL,
    base_reward numeric(18,9) NOT NULL,
    energy_bonus numeric(18,9) DEFAULT 0 NOT NULL,
    time_bonus numeric(18,9) DEFAULT 0 NOT NULL,
    reputation_multiplier numeric(5,4) DEFAULT 1.0 NOT NULL,
    tx_hash character varying(64),
    tx_status character varying(20) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    confirmed_at timestamp without time zone
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: payout_intents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payout_intents (
    id integer NOT NULL,
    task_id uuid NOT NULL,
    executor_address character varying(255) NOT NULL,
    idempotency_key character varying(255) NOT NULL,
    nonce bigint NOT NULL,
    query_id bigint,
    executor_reward_ton numeric(20,9) NOT NULL,
    platform_fee_ton numeric(20,9) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    used boolean DEFAULT false NOT NULL,
    used_at timestamp without time zone
);


ALTER TABLE public.payout_intents OWNER TO postgres;

--
-- Name: payout_intents_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payout_intents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payout_intents_id_seq OWNER TO postgres;

--
-- Name: payout_intents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payout_intents_id_seq OWNED BY public.payout_intents.id;


--
-- Name: payout_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payout_transactions (
    id integer NOT NULL,
    task_id uuid NOT NULL,
    executor_address character varying(255) NOT NULL,
    tx_hash character varying(255),
    query_id bigint,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    executor_reward_ton numeric(20,9) NOT NULL,
    platform_fee_ton numeric(20,9) NOT NULL,
    nonce bigint NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    sent_at timestamp without time zone,
    confirmed_at timestamp without time zone,
    failed_at timestamp without time zone,
    error_message text
);


ALTER TABLE public.payout_transactions OWNER TO postgres;

--
-- Name: payout_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payout_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payout_transactions_id_seq OWNER TO postgres;

--
-- Name: payout_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payout_transactions_id_seq OWNED BY public.payout_transactions.id;


--
-- Name: requesters; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.requesters (
    requester_address character varying(48) NOT NULL,
    gstd_balance numeric(18,9) DEFAULT 0 NOT NULL,
    reputation numeric(5,4) DEFAULT 0.5 NOT NULL,
    total_tasks_created integer DEFAULT 0 NOT NULL,
    total_tasks_completed integer DEFAULT 0 NOT NULL,
    total_ton_spent numeric(18,9) DEFAULT 0 NOT NULL,
    average_validation_success_rate numeric(5,4) DEFAULT 1.0 NOT NULL,
    timely_payments_count integer DEFAULT 0 NOT NULL,
    last_activity_at timestamp without time zone NOT NULL
);


ALTER TABLE public.requesters OWNER TO postgres;

--
-- Name: slashings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.slashings (
    slashing_id uuid NOT NULL,
    device_id character varying(255) NOT NULL,
    task_id uuid,
    assignment_id uuid,
    reason character varying(50) NOT NULL,
    severity character varying(10) NOT NULL,
    amount_gstd numeric(18,9) NOT NULL,
    slashed_at timestamp without time zone NOT NULL
);


ALTER TABLE public.slashings OWNER TO postgres;

--
-- Name: task_assignments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_assignments (
    assignment_id uuid NOT NULL,
    task_id uuid NOT NULL,
    device_id character varying(255) NOT NULL,
    assigned_at timestamp without time zone NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    status character varying(20) NOT NULL,
    result_data jsonb,
    proof_signature character varying(255),
    proof_timestamp bigint,
    proof_energy_consumed integer,
    proof_execution_time_ms integer,
    validation_status character varying(20),
    validation_method character varying(20),
    payment_tx_hash character varying(64),
    payment_status character varying(20)
);


ALTER TABLE public.task_assignments OWNER TO postgres;

--
-- Name: task_queue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_queue (
    queue_id uuid NOT NULL,
    task_id uuid NOT NULL,
    priority_score numeric(10,6) NOT NULL,
    queued_at timestamp without time zone NOT NULL,
    assigned_at timestamp without time zone,
    retry_count integer DEFAULT 0 NOT NULL,
    status character varying(20) NOT NULL
);


ALTER TABLE public.task_queue OWNER TO postgres;

--
-- Name: tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tasks (
    task_id uuid NOT NULL,
    requester_address character varying(48) NOT NULL,
    task_type character varying(20) NOT NULL,
    operation character varying(50) NOT NULL,
    model character varying(50),
    input_source character varying(10) NOT NULL,
    input_hash character varying(255),
    input_data text,
    constraints_time_limit_sec integer NOT NULL,
    constraints_max_energy_mwh integer NOT NULL,
    reward_amount_ton numeric(18,9) NOT NULL,
    validation_method character varying(20) NOT NULL,
    priority_score numeric(10,6) NOT NULL,
    status character varying(20) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    assigned_at timestamp without time zone,
    completed_at timestamp without time zone,
    escrow_address character varying(48) NOT NULL,
    escrow_amount_ton numeric(18,9) NOT NULL,
    assigned_device character varying(255),
    timeout_at timestamp without time zone,
    executor_payout_status character varying(50) DEFAULT 'pending'::character varying,
    arbitration_count integer DEFAULT 0
);


ALTER TABLE public.tasks OWNER TO postgres;

--
-- Name: validations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.validations (
    validation_id uuid NOT NULL,
    task_id uuid NOT NULL,
    assignment_id uuid NOT NULL,
    validation_method character varying(20) NOT NULL,
    reference_result jsonb,
    majority_results jsonb[],
    ai_check_confidence numeric(5,4),
    human_check_result boolean,
    human_checker_address character varying(48),
    validation_result character varying(20) NOT NULL,
    validated_at timestamp without time zone
);


ALTER TABLE public.validations OWNER TO postgres;

--
-- Name: wallet_access_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wallet_access_log (
    id integer NOT NULL,
    wallet_address character varying(66) NOT NULL,
    operation character varying(50) NOT NULL,
    success boolean NOT NULL,
    details text,
    accessed_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.wallet_access_log OWNER TO postgres;

--
-- Name: wallet_access_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.wallet_access_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wallet_access_log_id_seq OWNER TO postgres;

--
-- Name: wallet_access_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.wallet_access_log_id_seq OWNED BY public.wallet_access_log.id;


--
-- Name: failed_payouts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_payouts ALTER COLUMN id SET DEFAULT nextval('public.failed_payouts_id_seq'::regclass);


--
-- Name: payout_intents id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payout_intents ALTER COLUMN id SET DEFAULT nextval('public.payout_intents_id_seq'::regclass);


--
-- Name: payout_transactions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payout_transactions ALTER COLUMN id SET DEFAULT nextval('public.payout_transactions_id_seq'::regclass);


--
-- Name: wallet_access_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wallet_access_log ALTER COLUMN id SET DEFAULT nextval('public.wallet_access_log_id_seq'::regclass);


--
-- Data for Name: device_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.device_metrics (metric_id, device_id, metric_type, metric_value, recorded_at) FROM stdin;
\.


--
-- Data for Name: devices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.devices (device_id, wallet_address, device_type, reputation, total_tasks, successful_tasks, failed_tasks, total_energy_consumed, average_response_time_ms, cached_models, last_seen_at, is_active, slashing_count) FROM stdin;
\.


--
-- Data for Name: failed_payouts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.failed_payouts (id, task_id, payout_type, recipient_address, amount_gstd, error_message, retry_count, max_retries, created_at, last_retry_at, status) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (payment_id, task_id, assignment_id, device_address, amount_ton, base_reward, energy_bonus, time_bonus, reputation_multiplier, tx_hash, tx_status, created_at, confirmed_at) FROM stdin;
\.


--
-- Data for Name: payout_intents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payout_intents (id, task_id, executor_address, idempotency_key, nonce, query_id, executor_reward_ton, platform_fee_ton, created_at, used, used_at) FROM stdin;
\.


--
-- Data for Name: payout_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payout_transactions (id, task_id, executor_address, tx_hash, query_id, status, executor_reward_ton, platform_fee_ton, nonce, created_at, sent_at, confirmed_at, failed_at, error_message) FROM stdin;
\.


--
-- Data for Name: requesters; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.requesters (requester_address, gstd_balance, reputation, total_tasks_created, total_tasks_completed, total_ton_spent, average_validation_success_rate, timely_payments_count, last_activity_at) FROM stdin;
\.


--
-- Data for Name: slashings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.slashings (slashing_id, device_id, task_id, assignment_id, reason, severity, amount_gstd, slashed_at) FROM stdin;
\.


--
-- Data for Name: task_assignments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_assignments (assignment_id, task_id, device_id, assigned_at, started_at, completed_at, status, result_data, proof_signature, proof_timestamp, proof_energy_consumed, proof_execution_time_ms, validation_status, validation_method, payment_tx_hash, payment_status) FROM stdin;
\.


--
-- Data for Name: task_queue; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_queue (queue_id, task_id, priority_score, queued_at, assigned_at, retry_count, status) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tasks (task_id, requester_address, task_type, operation, model, input_source, input_hash, input_data, constraints_time_limit_sec, constraints_max_energy_mwh, reward_amount_ton, validation_method, priority_score, status, created_at, assigned_at, completed_at, escrow_address, escrow_amount_ton, assigned_device, timeout_at, executor_payout_status, arbitration_count) FROM stdin;
\.


--
-- Data for Name: validations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.validations (validation_id, task_id, assignment_id, validation_method, reference_result, majority_results, ai_check_confidence, human_check_result, human_checker_address, validation_result, validated_at) FROM stdin;
\.


--
-- Data for Name: wallet_access_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.wallet_access_log (id, wallet_address, operation, success, details, accessed_at) FROM stdin;
\.


--
-- Name: failed_payouts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.failed_payouts_id_seq', 1, false);


--
-- Name: payout_intents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payout_intents_id_seq', 1, false);


--
-- Name: payout_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payout_transactions_id_seq', 1, false);


--
-- Name: wallet_access_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.wallet_access_log_id_seq', 1, false);


--
-- Name: device_metrics device_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.device_metrics
    ADD CONSTRAINT device_metrics_pkey PRIMARY KEY (metric_id);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (device_id);


--
-- Name: devices devices_wallet_address_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_wallet_address_key UNIQUE (wallet_address);


--
-- Name: failed_payouts failed_payouts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_payouts
    ADD CONSTRAINT failed_payouts_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (payment_id);


--
-- Name: payments payments_tx_hash_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_tx_hash_key UNIQUE (tx_hash);


--
-- Name: payout_intents payout_intents_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payout_intents
    ADD CONSTRAINT payout_intents_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: payout_intents payout_intents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payout_intents
    ADD CONSTRAINT payout_intents_pkey PRIMARY KEY (id);


--
-- Name: payout_intents payout_intents_task_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payout_intents
    ADD CONSTRAINT payout_intents_task_id_key UNIQUE (task_id);


--
-- Name: payout_transactions payout_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payout_transactions
    ADD CONSTRAINT payout_transactions_pkey PRIMARY KEY (id);


--
-- Name: requesters requesters_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.requesters
    ADD CONSTRAINT requesters_pkey PRIMARY KEY (requester_address);


--
-- Name: slashings slashings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.slashings
    ADD CONSTRAINT slashings_pkey PRIMARY KEY (slashing_id);


--
-- Name: task_assignments task_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_assignments
    ADD CONSTRAINT task_assignments_pkey PRIMARY KEY (assignment_id);


--
-- Name: task_queue task_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_queue
    ADD CONSTRAINT task_queue_pkey PRIMARY KEY (queue_id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (task_id);


--
-- Name: payout_transactions unique_task_executor; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payout_transactions
    ADD CONSTRAINT unique_task_executor UNIQUE (task_id, executor_address);


--
-- Name: validations validations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.validations
    ADD CONSTRAINT validations_pkey PRIMARY KEY (validation_id);


--
-- Name: wallet_access_log wallet_access_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wallet_access_log
    ADD CONSTRAINT wallet_access_log_pkey PRIMARY KEY (id);


--
-- Name: idx_assignments_assigned_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_assignments_assigned_at ON public.task_assignments USING btree (assigned_at);


--
-- Name: idx_assignments_device; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_assignments_device ON public.task_assignments USING btree (device_id);


--
-- Name: idx_assignments_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_assignments_status ON public.task_assignments USING btree (status);


--
-- Name: idx_assignments_task; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_assignments_task ON public.task_assignments USING btree (task_id);


--
-- Name: idx_devices_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_devices_active ON public.devices USING btree (is_active, reputation DESC);


--
-- Name: idx_devices_last_seen; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_devices_last_seen ON public.devices USING btree (last_seen_at);


--
-- Name: idx_devices_reputation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_devices_reputation ON public.devices USING btree (reputation DESC);


--
-- Name: idx_failed_payouts_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_failed_payouts_created_at ON public.failed_payouts USING btree (created_at DESC);


--
-- Name: idx_failed_payouts_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_failed_payouts_status ON public.failed_payouts USING btree (status, retry_count);


--
-- Name: idx_failed_payouts_task_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_failed_payouts_task_id ON public.failed_payouts USING btree (task_id);


--
-- Name: idx_intent_idempotency; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_intent_idempotency ON public.payout_intents USING btree (idempotency_key);


--
-- Name: idx_intent_task; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_intent_task ON public.payout_intents USING btree (task_id);


--
-- Name: idx_metrics_device_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_metrics_device_type ON public.device_metrics USING btree (device_id, metric_type, recorded_at DESC);


--
-- Name: idx_payments_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payments_created_at ON public.payments USING btree (created_at);


--
-- Name: idx_payments_device; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payments_device ON public.payments USING btree (device_address);


--
-- Name: idx_payments_tx_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payments_tx_status ON public.payments USING btree (tx_status);


--
-- Name: idx_payout_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payout_created ON public.payout_transactions USING btree (created_at);


--
-- Name: idx_payout_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payout_status ON public.payout_transactions USING btree (status);


--
-- Name: idx_payout_tx_hash; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payout_tx_hash ON public.payout_transactions USING btree (tx_hash);


--
-- Name: idx_queue_priority; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_queue_priority ON public.task_queue USING btree (status, priority_score DESC, queued_at);


--
-- Name: idx_queue_task; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_queue_task ON public.task_queue USING btree (task_id);


--
-- Name: idx_requesters_balance; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_requesters_balance ON public.requesters USING btree (gstd_balance DESC);


--
-- Name: idx_requesters_reputation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_requesters_reputation ON public.requesters USING btree (reputation DESC);


--
-- Name: idx_slashings_device; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_slashings_device ON public.slashings USING btree (device_id);


--
-- Name: idx_slashings_reason; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_slashings_reason ON public.slashings USING btree (reason);


--
-- Name: idx_tasks_arbitration_count; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tasks_arbitration_count ON public.tasks USING btree (arbitration_count);


--
-- Name: idx_tasks_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tasks_created_at ON public.tasks USING btree (created_at);


--
-- Name: idx_tasks_payout_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tasks_payout_status ON public.tasks USING btree (executor_payout_status);


--
-- Name: idx_tasks_requester; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tasks_requester ON public.tasks USING btree (requester_address);


--
-- Name: idx_tasks_status_priority; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tasks_status_priority ON public.tasks USING btree (status, priority_score DESC);


--
-- Name: idx_validations_result; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_validations_result ON public.validations USING btree (validation_result);


--
-- Name: idx_validations_task; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_validations_task ON public.validations USING btree (task_id);


--
-- Name: idx_wallet_access_log_accessed_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_wallet_access_log_accessed_at ON public.wallet_access_log USING btree (accessed_at);


--
-- Name: idx_wallet_access_log_address; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_wallet_access_log_address ON public.wallet_access_log USING btree (wallet_address);


--
-- Name: idx_wallet_access_log_success; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_wallet_access_log_success ON public.wallet_access_log USING btree (success);


--
-- Name: device_metrics device_metrics_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.device_metrics
    ADD CONSTRAINT device_metrics_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(device_id);


--
-- Name: payout_intents fk_intent_task; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payout_intents
    ADD CONSTRAINT fk_intent_task FOREIGN KEY (task_id) REFERENCES public.tasks(task_id) ON DELETE CASCADE;


--
-- Name: payout_transactions fk_payout_task; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payout_transactions
    ADD CONSTRAINT fk_payout_task FOREIGN KEY (task_id) REFERENCES public.tasks(task_id) ON DELETE CASCADE;


--
-- Name: payments payments_assignment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_assignment_id_fkey FOREIGN KEY (assignment_id) REFERENCES public.task_assignments(assignment_id);


--
-- Name: payments payments_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(task_id);


--
-- Name: slashings slashings_assignment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.slashings
    ADD CONSTRAINT slashings_assignment_id_fkey FOREIGN KEY (assignment_id) REFERENCES public.task_assignments(assignment_id);


--
-- Name: slashings slashings_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.slashings
    ADD CONSTRAINT slashings_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(device_id);


--
-- Name: slashings slashings_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.slashings
    ADD CONSTRAINT slashings_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(task_id);


--
-- Name: task_assignments task_assignments_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_assignments
    ADD CONSTRAINT task_assignments_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(device_id);


--
-- Name: task_assignments task_assignments_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_assignments
    ADD CONSTRAINT task_assignments_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(task_id);


--
-- Name: task_queue task_queue_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_queue
    ADD CONSTRAINT task_queue_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(task_id);


--
-- Name: validations validations_assignment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.validations
    ADD CONSTRAINT validations_assignment_id_fkey FOREIGN KEY (assignment_id) REFERENCES public.task_assignments(assignment_id);


--
-- Name: validations validations_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.validations
    ADD CONSTRAINT validations_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(task_id);


--
-- PostgreSQL database dump complete
--

\unrestrict uMQo6UIIUmeiPCP35OCHaog4aXApixrrXhbfUcq4Hcrk4d8gQBH3cTLHzJeeyI5

